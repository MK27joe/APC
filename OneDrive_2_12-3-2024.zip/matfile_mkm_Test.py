import numpy as np
import matplotlib.pyplot as plt

import scipy.io

res = scipy.io.loadmat('octuple_tank_data_11_11_24.mat')
